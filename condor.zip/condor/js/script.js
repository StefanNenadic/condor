
function menuResponsive() {
  let x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}


function showMessage() {
  let show = document.getElementById('show');
  show.classList.remove('d-none');

  setTimeout(function() { 
    show.classList.add('d-none');
  }, 1000);
}


function validate() {
  let email = document.getElementById('email');
  if (email.value === '' || email.value === null) {
    email.classList.add('validate');
    email.placeholder='This field is required!';
  }
}

